This project is first phase of a multiple phase project which corresponding to the Operations Research course:
- Assignment 0: Basic graphical interface and pending program.

To run the project, follow this sequence of commands:

``make``

``make run``
